<template>
  <div class="home-container">
    <h1>Welcome to our Job Management System</h1>
    <p>
      Our system allows you to efficiently manage job listings. You can view a list of available jobs,
      add new job listings, and edit or delete existing ones.
    </p>
    <p>Get started by navigating to the Job list or Add job pages using the links below:</p>

    
    <div class="navigation-links">
      <router-link to="/jobs" class="nav-link">View Job List</router-link>
      <router-link to="/add" class="nav-link">Add New Job</router-link>
    </div>
  </div>
</template>

<script>
export default {
  
};
</script>

<style scoped>

.home-container h1 {
  font-family: 'Arial', sans-serif;
}


.home-container {
  background-color: #f0f0f0;
}


.home-container p {
  color: #333;
}

.home-container .nav-link {
  background-color: #0ddadd;
  border-color: #0dbadd;
  color: #fff;
  text-decoration: none; 
  padding: 10px 20px;
  border-radius: 8px;
  transition: background-color 0.3s ease;
  cursor: pointer; 
  width:500px;
  margin-bottom: 10px;
  margin-left: 500px;
  text-align: center;
  margin-top: 20px;
}

.home-container .nav-link:hover {
  background-color: #0056b3;
  border-color: #0056b3;
}


.home-container .navigation-links {
  margin-top: 20px;
}


.home-container h1 {
  font-size: 2.5rem;
  margin-bottom: 20px;
}


.home-container p {
  font-size: 1.1rem;
  margin-bottom: 15px;
}

.home-container h1 {
  font-family: 'Arial', sans-serif;
  color: #333;
  font-size: 2.5rem;
  margin-bottom: 20px;
}

.home-container p {
  color: #555; 
  font-size: 1.2rem; 
  margin-bottom: 15px;
}


.navigation-links {
  display: flex;
  flex-direction: column;
  justify-content: center;
  margin-top: 20px;
}

.nav-link {
  margin: 0 10px;
}
</style>
